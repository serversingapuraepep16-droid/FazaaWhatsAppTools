package com.fazaa.whatsapptools;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    // 1000 username numeric 10 digit dimuat dari app/src/main/assets/admin_usernames.txt.
    // Catatan: daftar di dalam APK dapat diekstrak; ini bukan autentikasi yang aman.
    private static final String PUBLIC_PASSWORD = "fazaa_tools_pro";
    private final Set<String> allowedUsernames = new HashSet<>();
    private final int bg = Color.rgb(8, 11, 10), panel = Color.rgb(20, 27, 24), neon = Color.rgb(57, 255, 136), white = Color.WHITE, muted = Color.rgb(180, 195, 186);
    private EditText usernameField, passwordField, nameField, numberField;
    private String issue = "Akun WhatsApp diblokir";
    private LinearLayout root;

    @Override public void onCreate(Bundle state) { super.onCreate(state); loadUsernames(); showLogin(); }
    private void loadUsernames() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(getAssets().open("admin_usernames.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.matches("[1-9][0-9]{9}")) allowedUsernames.add(line);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Daftar username tidak dapat dibaca", Toast.LENGTH_LONG).show();
        }
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(22),dp(18),dp(22),dp(22)); l.setBackgroundColor(bg); return l; }
    private void base(String title, String subtitle) {
        root = column(); ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
        TextView logo = text("FAZAA", 30, neon, true); logo.setGravity(Gravity.CENTER); root.addView(logo, new LinearLayout.LayoutParams(-1, dp(55)));
        TextView sub = text(title, 21, white, true); sub.setGravity(Gravity.CENTER); root.addView(sub, new LinearLayout.LayoutParams(-1, dp(38)));
        TextView desc = text(subtitle, 13, muted, false); desc.setGravity(Gravity.CENTER); root.addView(desc, new LinearLayout.LayoutParams(-1, dp(38)));
        View line = new View(this); line.setBackgroundColor(neon); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(2)); lp.setMargins(0,dp(10),0,dp(18)); root.addView(line,lp);
    }
    private EditText input(String hint, boolean password) { EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(white); e.setHintTextColor(muted); e.setHint(hint); e.setPadding(dp(14),dp(10),dp(14),dp(10)); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(neon)); if(password) e.setInputType(129); root.addView(e,new LinearLayout.LayoutParams(-1,dp(52))); return e; }
    private Button button(String label, Runnable action) { Button b = new Button(this); b.setText(label); b.setTextColor(bg); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(neon)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(50)); p.setMargins(0,dp(8),0,dp(4)); root.addView(b,p); b.setOnClickListener(v -> action.run()); return b; }
    private void showLogin() {
        base("WHATSAPP TOOLS", "Masuk menggunakan kredensial admin");
        TextView note = text("Username khusus admin • Password bersama",14,muted,false); root.addView(note); usernameField = input("Username admin",false); passwordField = input("Password",true);
        button("MASUK", () -> { String u=usernameField.getText().toString().trim(); String p=passwordField.getText().toString(); if(allowedUsernames.contains(u) && PUBLIC_PASSWORD.equals(p)) showHome(); else Toast.makeText(this,"Username atau password salah",Toast.LENGTH_SHORT).show(); });
        TextView hint=text("Akses lokal perangkat. Jangan bagikan username admin.",12,muted,false); hint.setPadding(0,dp(14),0,0); root.addView(hint);
    }
    private void showHome() {
        base("DASHBOARD", "Alat bantuan akun WhatsApp");
        button("✉  BUAT TEKS BANDING", () -> showAppeal());
        button("🛡  PANDUAN PEMULIHAN", () -> showInfo("Panduan Pemulihan", "1. Buka WhatsApp resmi.\n2. Pada layar pemblokiran, pilih opsi Tinjau jika tersedia.\n3. Jelaskan masalah dengan jujur dan singkat.\n4. Tunggu keputusan dari WhatsApp.\n\nAplikasi pihak ketiga tidak dapat membuka blokir secara otomatis."));
        button("🚫  SIMULASI WA BANNED", () -> showInfo("Simulasi Status Banned", "DEMO: Akun tidak dapat digunakan sementara.\n\nIni hanya simulasi di aplikasi FAZAA dan tidak mengubah status akun WhatsApp sungguhan."));
        button("🛡  KEAMANAN / ANTI-SPAM", () -> showInfo("Keamanan Akun", "• Gunakan aplikasi WhatsApp resmi.\n• Hindari pesan massal atau pesan berulang yang tidak diminta.\n• Hormati permintaan orang untuk berhenti dihubungi.\n• Jangan gunakan aplikasi modifikasi atau otomatisasi yang melanggar ketentuan."));
        button("🌐  DUKUNGAN RESMI WHATSAPP", () -> { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.whatsapp.com/contact/"))); } catch(Exception e) { Toast.makeText(this,"Tidak dapat membuka browser",Toast.LENGTH_SHORT).show(); } });
        button("KELUAR", () -> showLogin());
    }
    private void showAppeal() {
        base("GENERATOR BANDING", "Isi data yang benar, lalu buat dan salin teks");
        nameField=input("Nama (opsional)",false); numberField=input("Nomor WhatsApp, contoh +62...",false);
        TextView choice=text("Jenis masalah:",14,white,true); root.addView(choice);
        button("Akun diblokir", () -> { issue="Akun WhatsApp diblokir"; Toast.makeText(this,"Dipilih: akun diblokir",Toast.LENGTH_SHORT).show(); });
        button("Akun sedang ditinjau", () -> { issue="Akun WhatsApp sedang ditinjau"; Toast.makeText(this,"Dipilih: akun ditinjau",Toast.LENGTH_SHORT).show(); });
        button("WhatsApp Business diblokir", () -> { issue="Akun WhatsApp Business diblokir"; Toast.makeText(this,"Dipilih: WhatsApp Business",Toast.LENGTH_SHORT).show(); });
        button("BUAT TEKS BANDING", () -> showGeneratedAppeal());
        button("KEMBALI", () -> showHome());
    }
    private void showGeneratedAppeal() {
        String name=nameField.getText().toString().trim(), number=numberField.getText().toString().trim();
        String appeal="PERMOHONAN PENINJAUAN ULANG AKUN WHATSAPP\n\nKepada Tim Dukungan WhatsApp,\n\nSaya memohon peninjauan ulang terhadap status akun saya dengan rincian berikut.\nNama: "+(name.isEmpty()?"[Isi nama]":name)+"\nNomor WhatsApp: "+(number.isEmpty()?"[Isi nomor dengan kode negara]":number)+"\nPermasalahan: "+issue+"\n\nDengan hormat, saya meminta tim WhatsApp memeriksa kembali status akun tersebut dan menjelaskan, jika memungkinkan, alasan pembatasan yang diterapkan. Saya memahami bahwa WhatsApp menerapkan ketentuan untuk melindungi keamanan, privasi, dan kenyamanan seluruh pengguna.\n\nJika aktivitas akun saya terdeteksi tidak sesuai dengan ketentuan, saya mohon agar konteksnya ditinjau secara menyeluruh. Saya tidak bermaksud mengganggu pengguna lain. Apabila terdapat pola penggunaan yang perlu diperbaiki, saya bersedia mematuhi petunjuk dan ketentuan yang berlaku. Saya juga bersedia memberikan informasi tambahan yang diperlukan melalui saluran dukungan resmi.\n\nSaya menggunakan WhatsApp untuk komunikasi sehari-hari dan berharap akun ini dapat dipulihkan apabila hasil pemeriksaan menunjukkan bahwa pemulihan memungkinkan. Saya memahami bahwa keputusan akhir sepenuhnya berada pada tim WhatsApp dan bahwa pengajuan ini bukan jaminan pembukaan blokir.\n\nTerima kasih atas waktu dan perhatian tim Dukungan WhatsApp.\n\nHormat saya,\n"+(name.isEmpty()?"Pemilik akun":name)+"\n"+(number.isEmpty()?"Nomor: [isi nomor]":"Nomor: "+number);
        base("TEKS BANDING SIAP", "Periksa kembali data sebelum mengirim");
        TextView body=text(appeal,14,white,false); body.setGravity(Gravity.TOP); body.setPadding(dp(14),dp(14),dp(14),dp(14)); body.setBackgroundColor(panel); root.addView(body,new LinearLayout.LayoutParams(-1,-2));
        button("SALIN TEKS BANDING", () -> { ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("Teks Banding WhatsApp",appeal)); Toast.makeText(this,"Teks banding disalin",Toast.LENGTH_SHORT).show(); });
        button("BUKA DUKUNGAN WHATSAPP", () -> startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.whatsapp.com/contact/"))));
        button("KEMBALI KE FORM", () -> showAppeal());
    }
    private void showInfo(String title, String message) { base(title,"Informasi FAZAA WHATSAPP TOOLS"); TextView body=text(message,15,white,false); body.setGravity(Gravity.TOP); body.setPadding(dp(14),dp(14),dp(14),dp(14)); body.setBackgroundColor(panel); root.addView(body,new LinearLayout.LayoutParams(-1,-2)); button("KEMBALI", () -> showHome()); }
}
