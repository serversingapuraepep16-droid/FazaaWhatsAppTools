# FAZAA WHATSAPP TOOLS — Android native project

This is a native Android Java project (not an HTML/WebView app). Features include local login, appeal-text generator, copy-to-clipboard, recovery guidance, a clearly labelled ban simulation, anti-spam guidance, and opening WhatsApp's official contact page.

## Login
- 1000 unique usernames, each exactly 10 numeric digits, are stored in `app/src/main/assets/admin_usernames.txt`.
- Shared password: `fazaa_tools_pro`

## Security limitation
This is a local demo login. Because the username list and password are bundled in the APK, they can be extracted by someone who inspects the APK. It does not provide secure admin authentication. A backend/server is needed if usernames must remain secret or access needs to be revoked remotely.

## Build the APK automatically in GitHub
1. Upload the contents of this project to a new GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build FAZAA APK** and press **Run workflow** (or push to `main`/`master`).
4. When the run finishes, open it and download the artifact named `FAZAA-WHATSAPP-TOOLS-APK`. It contains `app-debug.apk`.

The project ZIP includes `.github/workflows/build-apk.yml` to automate the build. This current environment does not have the Android SDK or Gradle installed and cannot reach their download servers, so it cannot compile the APK binary directly here.

No third-party app can guarantee WhatsApp unbanning; appeals go through official WhatsApp support and decisions remain with WhatsApp.
